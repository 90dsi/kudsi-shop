/* Sign in / create account / forgot password */

const params = new URLSearchParams(window.location.search);
const redirectTo = params.get("next");
let mode = params.get("mode") === "signup" ? "signup" : "login";

const $ = (s) => document.querySelector(s);

function setMode(next) {
  mode = next;
  const signup = mode === "signup";
  const forgot = mode === "forgot";

  $("#authTitle").textContent = signup
    ? "Create your account"
    : forgot
      ? "Reset your password"
      : "Welcome back";
  $("#authSub").textContent = signup
    ? "Track orders, top up your balance and get codes instantly."
    : forgot
      ? "Enter your email and we'll send a secure, single-use reset link."
      : "Sign in to see your orders, balance and codes.";

  $("#submitBtn").textContent = signup ? "Create account" : forgot ? "Send reset link" : "Sign in";
  $("#nameField").hidden = !signup;
  $("#password").closest(".field").hidden = forgot;
  $("#forgotRow").hidden = forgot;
  $("#password").autocomplete = signup ? "new-password" : "current-password";
  $("#password").placeholder = signup ? "At least 8 characters" : "Your password";
  $("#passwordHint").hidden = !signup;
  $("#altText").textContent = signup ? "Already have an account?" : "New here?";
  $("#altLink").textContent = signup ? "Sign in" : "Create an account";
  $("#authError").hidden = true;
  $("#authError").classList.remove("ok");
  $("#suspendedNote").hidden = !params.get("suspended");
  if (!forgot) setTimeout(() => $("#email").focus(), 60);
}

$("#altLink").addEventListener("click", (e) => {
  e.preventDefault();
  setMode(mode === "login" ? "signup" : "login");
});

$("#forgotLink").addEventListener("click", (e) => {
  e.preventDefault();
  setMode(mode === "forgot" ? "login" : "forgot");
});

$("#authForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = $("#email").value.trim();
  const password = $("#password").value;
  const name = $("#name").value.trim();
  const errorBox = $("#authError");
  const button = $("#submitBtn");

  errorBox.hidden = true;
  errorBox.classList.remove("ok");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
    errorBox.textContent = "Enter a valid email address.";
    errorBox.hidden = false;
    return;
  }
  if (mode !== "forgot" && password.length < 8) {
    errorBox.textContent = "Password must be at least 8 characters.";
    errorBox.hidden = false;
    return;
  }

  const original = button.textContent;
  button.disabled = true;
  button.textContent = mode === "forgot" ? "Sending…" : "Please wait…";
  try {
    if (mode === "forgot") {
      const result = await api.post("/api/auth/forgot", { email });
      errorBox.textContent = result.message || "If an account exists, a reset link is on its way.";
      errorBox.classList.add("ok");
      errorBox.hidden = false;
      button.disabled = false;
      button.textContent = original;
      return;
    }

    const path = mode === "signup" ? "/api/auth/signup" : "/api/auth/login";
    const { user } = await api.post(path, { email, password, name });
    const fallback = user.role === "admin" ? "/admin.html" : "/dashboard.html";
    window.location.href = redirectTo && redirectTo.startsWith("/") ? redirectTo : fallback;
  } catch (error) {
    errorBox.textContent = error.message;
    errorBox.hidden = false;
    button.disabled = false;
    button.textContent = original;
  }
});

(async function init() {
  loadSite().then((site) => {
    const contact = (site && site.contact) || {};
    const tgLink = contact.telegramLink || "https://t.me/t4m31";
    const handle = contact.telegramUsername || "@t4m31";
    const telegramCard = $("#telegramCard");
    if (telegramCard) {
      telegramCard.href = tgLink;
      $("#telegramHandle").textContent = handle;
    }
    const discordCard = $("#discordCard");
    if (discordCard) {
      if (contact.discordLink) {
        discordCard.href = contact.discordLink;
        discordCard.hidden = false;
        const label = contact.discordLink.replace(/^https?:\/\/(www\.)?/, "").slice(0, 34);
        $("#discordHandle").textContent = label;
      } else {
        discordCard.hidden = true;
      }
    }
    const fallback = $("#contactFallback");
    if (fallback) fallback.hidden = Boolean(contact.telegramLink || contact.discordLink);
    if (site && site.app && site.app.name) document.title = `Sign in — ${site.app.name}`;
  });

  try {
    const { user } = await api.get("/api/auth/me");
    if (user) {
      window.location.href =
        redirectTo && redirectTo.startsWith("/")
          ? redirectTo
          : user.role === "admin"
            ? "/admin.html"
            : "/dashboard.html";
      return;
    }
  } catch {
    /* not signed in */
  }
  setMode(mode);
})();
